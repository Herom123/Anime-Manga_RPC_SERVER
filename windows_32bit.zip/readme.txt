Doesn't it automatically start when you restart your computer?
Open task manager with pressing "CTRL", "SHIFT", and "ESC" same 
time and make sure it's there or not. If it's there don't worry, it works. 
If it's not then you have to make it manually :T

 - Press "Windows key" and "R" same time, (It should open a window called "Run")
 - Write "shell:startup" to Run, (It should open a folder named "Startup" or "Startup")
 - After that, move "server_win.exe" file to folder that opens, 
 - Then, double click to "server_win.exe" file to start.
 - And it's done, you can check if it works by restarting your computer.
