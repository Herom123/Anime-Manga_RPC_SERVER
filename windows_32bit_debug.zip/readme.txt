########################################################

Installation:

 - open "startup_windows.bat"
 - if a window appears that says "Windows protected your PC" just 
click "More Info" text and press "Run anyway" button
 - click "Yes"
 - select option 1 and wait

if installation was successful, you can delete all files here...

########################################################

Starting without installation:

 First way:
   - double click on "server_win.exe"
   - if a window opens that called "Windows Security Alert", just click 
"Allow access". If there is nothing, don't mind it.
 
Second way:
  - open "startup_windows.bat"
  - if a window appears that says "Windows protected your PC" just 
click "More Info" text and press "Run anyway" button
  - click "Yes"
  - select option 3

########################################################

Doesn't it automatically start when you restart your computer?
Open task manager with pressing "CTRL", "SHIFT", and "ESC" same 
time and make sure it's there or not. If it's there don't worry, it works. 
If it's not then you have to make it manually :T

 - Press "Windows key" and "R" same time, (It should open a window called "Run")
 - Write "shell:startup" to Run, (It should open a folder named "Startup" or "Startup")
 - After that, move "server_win.exe" file to folder that opens, 
 - Then, double click to "server_win.exe" file to start.
 - And it's done, you can check if it works by restarting your computer.

########################################################
#################### Made By Herom123 ###################
########################################################